﻿using ChristmasPastryShop.Core.Contracts;
using ChristmasPastryShop.Models.Booths;
using ChristmasPastryShop.Models.Booths.Contracts;
using ChristmasPastryShop.Models.Cocktails;
using ChristmasPastryShop.Models.Cocktails.Contracts;
using ChristmasPastryShop.Models.Delicacies;
using ChristmasPastryShop.Models.Delicacies.Contracts;
using ChristmasPastryShop.Repositories;
using ChristmasPastryShop.Repositories.Contracts;
using ChristmasPastryShop.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks.Dataflow;

namespace ChristmasPastryShop.Core
{
    public class Controller : IController
    {
        private IRepository<IBooth> booths;
        private int boothId = 0;
        public Controller()
        {
            this.booths = new BoothRepository();
        }


        public string AddBooth(int capacity)
        {
            boothId ++;
            IBooth booth = new Booth(boothId, capacity);

            this.booths.AddModel(booth);
            return string.Format(OutputMessages.NewBoothAdded, boothId, capacity);
        }

        public string AddCocktail(int boothId, string cocktailTypeName, string cocktailName, string size)
        {
            ICocktail cocktail;
            IBooth booth = this.booths.Models.FirstOrDefault(b => b.BoothId == boothId);

            if (cocktailTypeName != nameof(MulledWine) && cocktailTypeName != nameof(Hibernation))
            {
                return string.Format(OutputMessages.InvalidCocktailType, cocktailTypeName);
            }

            if (size != "Small" && size != "Middle"  && size != "Large" )
            {
                return string.Format(OutputMessages.InvalidCocktailSize, size);
            }

            if (booth.CocktailMenu.Models.Any(c => c.Name == cocktailName && c.Size == size))
            {
                return string.Format(OutputMessages.CocktailAlreadyAdded,size, cocktailName);
            }

            cocktail = cocktailTypeName switch 
            {
               nameof(MulledWine) => new MulledWine(cocktailName,size),
               nameof(Hibernation) => new Hibernation(cocktailName,size),   
            };

            booth.CocktailMenu.AddModel(cocktail);

           return string.Format(OutputMessages.NewCocktailAdded, size, cocktailName, cocktailTypeName);
        }

        public string AddDelicacy(int boothId, string delicacyTypeName, string delicacyName)
        {
            IBooth booth = this.booths.Models.FirstOrDefault(b => b.BoothId == boothId);

            if (booth.DelicacyMenu.Models.Any(d => d.Name == delicacyName))
            {
                return string.Format(OutputMessages.DelicacyAlreadyAdded, delicacyName);
            }

            if (delicacyTypeName != nameof(Gingerbread) && delicacyTypeName != nameof(Stolen))
            {
                return string.Format(OutputMessages.InvalidDelicacyType, delicacyTypeName);
            }

            IDelicacy delicacy = delicacyTypeName switch
            {
                nameof(Gingerbread) => new Gingerbread(delicacyName),
                nameof(Stolen) => new Stolen(delicacyName),
            };

            booth.DelicacyMenu.AddModel(delicacy);

            return string.Format(OutputMessages.NewDelicacyAdded,delicacyTypeName, delicacyName);



        }

        public string BoothReport(int boothId)
        {
            IBooth booth = this.booths.Models.FirstOrDefault( b => b.BoothId == boothId);

            return booth.ToString();
        }

        public string LeaveBooth(int boothId)
        {
            IBooth booth = this.booths.Models.FirstOrDefault(b => b.BoothId == boothId);
            booth.Charge();
            booth.ChangeStatus();

            var message = new StringBuilder();

            var currentBill = $"{booth.Turnover:f2}";
            message.AppendLine(string.Format(OutputMessages.GetBill, currentBill));
            message.AppendLine(string.Format(OutputMessages.BoothIsAvailable, boothId));
            return message.ToString().TrimEnd();
        }

        public string ReserveBooth(int countOfPeople)
        {
            var booth = this.booths.Models.Where(b => !b.IsReserved && b.Capacity >= countOfPeople)
                                                   .OrderBy(b => b.Capacity)
                                                   .ThenByDescending(b => b.BoothId).FirstOrDefault();

            if (booth == null)
            {
                return string.Format(OutputMessages.NoAvailableBooth, countOfPeople);

            }

            
            
            booth.ChangeStatus();

            return string.Format(OutputMessages.BoothReservedSuccessfully, booth.BoothId, countOfPeople);
            


        }

        public string TryOrder(int boothId, string order)
        {
            
            string itemType = null;
            string itemName = null;
            int itemCount = 0;
            string cocktailSize = null;
            double amount;

            var orderArgs = order.Split("/", StringSplitOptions.RemoveEmptyEntries);
            
            if (orderArgs.Length == 3) 
            { 
               itemType = orderArgs[0];
               itemName = orderArgs[1];
               itemCount = int.Parse(orderArgs[2]);
            } 

            if (orderArgs.Length == 4)
            {

                itemType = orderArgs[0];
                itemName = orderArgs[1];
                itemCount = int.Parse(orderArgs[2]);
                cocktailSize = orderArgs[3];

            }

            IBooth booth = this.booths.Models.FirstOrDefault(b => b.BoothId == boothId);


            if (itemType != nameof(MulledWine) &&
                itemType != nameof(Hibernation) &&
                itemType != nameof(Gingerbread) &&
                itemType != nameof(Stolen)) 
            {
                return string.Format(OutputMessages.NotRecognizedType, itemType);
            }

            if (!booth.DelicacyMenu.Models.Any( d => d.GetType().Name == itemType && d.Name == itemName) &&
                !booth.CocktailMenu.Models.Any(c => c.GetType().Name == itemType && c.Name == itemName))
            {
                return string.Format(OutputMessages.NotRecognizedItemName, itemType, itemName);
            }


            ICocktail cocktail;
            IDelicacy delicacy;

            if (itemType == nameof(MulledWine) || itemType == nameof(Hibernation))
            {
                 cocktail = booth.CocktailMenu.Models.FirstOrDefault(x => x.GetType().Name == itemType && x.Name == itemName && x.Size == cocktailSize);

                if (cocktail == null)
                {
                    return string.Format(OutputMessages.CocktailStillNotAdded, cocktailSize, itemName);
                }

                amount = cocktail.Price * itemCount;
                booth.UpdateCurrentBill(amount);

                return string.Format(OutputMessages.SuccessfullyOrdered, booth.BoothId,  itemCount, itemName);

            }

            
            delicacy = booth.DelicacyMenu.Models.FirstOrDefault(x => x.GetType().Name == itemType && x.Name == itemName);

            if (delicacy == null)
            {
               return string.Format(OutputMessages.DelicacyStillNotAdded, itemType, itemName);
            }

            amount = delicacy.Price * itemCount;
            booth.UpdateCurrentBill(amount);

            return string.Format(OutputMessages.SuccessfullyOrdered, booth.BoothId, itemCount, itemName);
            
        }
    }
}
