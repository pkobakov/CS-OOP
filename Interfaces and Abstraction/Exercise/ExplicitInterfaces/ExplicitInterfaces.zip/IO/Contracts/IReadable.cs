﻿
namespace ExplicitInterfaces.IO.Contracts
{
   public interface IReadable
    {
        string ReadLine();
    }
}
